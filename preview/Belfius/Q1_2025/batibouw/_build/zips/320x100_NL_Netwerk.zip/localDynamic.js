localDynamicData = {
	"variationName": "NL_Netwerk",
	"campaignName": "NL",
	"dimensionName": {
		"300x250": "300x250_NL_Netwerk",
		"300x600": "300x600_NL_Netwerk",
		"320x100": "320x100_NL_Netwerk"
	},
	"headline": {
		"default": "450 kantoren.<br>350 woonexperts.<br>1 doel.",
		"300x250": "",
		"300x600": "",
		"320x100": ""
	},
	"subtext": {
		"default": "U een scherpe rente en<br>de beste service bezorgen.",
		"300x250": "",
		"300x600": "",
		"320x100": "U een scherpe rente<br>en de beste service<br>bezorgen."
	},
	"ctaText": {
		"default": "Simuleer uw krediet",
		"300x250": "Simuleer uw krediet",
		"300x600": "Simuleer uw krediet",
		"320x100": "Simuleer uw krediet"
	},
	"disclaimer": {
		"default": "Let op, geld lenen<br>kost ook geld.",
		"300x250": "",
		"300x600": "",
		"320x100": "Let op, geld lenen kost ook geld."
	}
}