localDynamicData = {
	"variationName": "FR_Scherp_Tarief",
	"campaignName": "FR",
	"dimensionName": {
		"300x250": "300x250_FR_Scherp_Tarief",
		"300x600": "300x600_FR_Scherp_Tarief"
	},
	"headline": {
		"default": "Tarif avantageux<br>cherche nouvelle<br>maison.",
		"300x250": "",
		"300x600": ""
	},
	"subtext": {
		"default": "Une combinaison parfaite en<br>perspective.",
		"300x250": "",
		"300x600": ""
	},
	"ctaText": {
		"default": "Démarrez votre simulation de crédit",
		"300x250": "",
		"300x600": ""
	},
	"disclaimer": {
		"default": "Attention, emprunter de l’argent coûte aussi de l’argent.",
		"300x250": "Attention, emprunter de<br>l’argent coûte aussi de l’argent.",
		"300x600": "<span style=font-size:10px>Attention, emprunter<br>de l’argent coûte<br>aussi de l’argent.</span>"
	}
}