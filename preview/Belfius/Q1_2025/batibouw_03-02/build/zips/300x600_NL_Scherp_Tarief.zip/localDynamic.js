localDynamicData = {
	"variationName": "NL_Scherp_Tarief",
	"campaignName": "NL",
	"dimensionName": {
		"300x250": "300x250_NL_Scherp_Tarief",
		"300x600": "300x600_NL_Scherp_Tarief"
	},
	"headline": {
		"default": "Scherp tarief zoekt nieuwe thuis.",
		"300x250": "Scherp tarief zoekt<br>nieuwe thuis.",
		"300x600": "Scherp tarief<br>zoekt nieuwe<br>thuis."
	},
	"subtext": {
		"default": "Perfecte match in de maak.",
		"300x250": "",
		"300x600": ""
	},
	"ctaText": {
		"default": "Simuleer uw krediet",
		"300x250": "",
		"300x600": ""
	},
	"disclaimer": {
		"default": "Let op, geld lenen<br>kost ook geld.",
		"300x250": "",
		"300x600": ""
	}
}