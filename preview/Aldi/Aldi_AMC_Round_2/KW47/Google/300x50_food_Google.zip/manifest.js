FT.manifest({
	"filename":"index.html",
	"width":300,
	"height":50,
	"clickTagCount":1,
	"hideBrowsers": ["ie8", "ie9"]
});
